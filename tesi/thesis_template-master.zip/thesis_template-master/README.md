# thesis_template
A simple Thesis template for the Bachelor Degree in Computer Science @Unipadova
