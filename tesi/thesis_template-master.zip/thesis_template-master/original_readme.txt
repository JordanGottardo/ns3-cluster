        %%******************************************%%
        %%                                          %%
        %%        Modello di tesi di laurea         %%
        %%            di Andrea Giraldin            %%
        %%                                          %%
        %%             2 novembre 2012              %%
        %%                                          %%
        %%******************************************%%
		
Desidero condividere con tutti il template LaTeX che ho creato e 
utilizzato per redigere la mia tesi.
Lo so, non � il massimo dello splendore ma la trovo una buona base
da cui partire.
E' presente tutto ci� che serve per scrivere una tesi completa.
I capitoli rispecchiano quali dovrebbero essere gli argomenti trattati
nel corso della tesi, a voi la libert� di riorganizzarli come preferite.
Come editor vi consiglio TeXnicCenter che permette di aprire il file
.tcp (file progetto).
Nel file tesi-config.tex trovate le configurazioni per ogni pacchetto
utilizzato.
Il file compile-tesi.bat permette di compilare la tesi in modo completo
aggiornando sia bibliografia che glossario.
Nel capitolo 1 � presente un esempio di utilizzo del glossarioe della 
bibliografia.
Sono tutte piccole cose che mi hanno impiegato tempo e che volevo
risparmiare a voi.
In bocca al lupo per la vostra laurea :)
						
						  by MakeTheStory


Per chi utilizza Windows, in particolare MikTex, � bene installare il package cm-super 
avendo MikTex chiuso, per far s� che la compilazione vada a buon fine senza
l'insorgere di alcun problema.